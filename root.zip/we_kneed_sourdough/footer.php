
        <footer class="footer">
            <div class="footer__row">
            <div class="footer__links">
                    <a href="#" class='js--show_more_btn'>About us</a>
            </div>
            <div class="footer__social">
                    <a href="#"><ion-icon class="logo-facebook" name="logo-facebook"></ion-icon></a>
                    <a href="#"><ion-icon class="logo-instagram" name="logo-instagram"></ion-icon></a>
                    <a href="#"><ion-icon class="logo-twitter" name="logo-twitter"></ion-icon></a>
                    <a href="#"><ion-icon class="logo-snapchat" name="logo-snapchat"></ion-icon></a>
            </div>
            </div>
            <div class="footer__copyright">
                <p>
                    Copyright &copy; 2020 We need sourdough. All rights reserved.
                </p>
            </div>
        </footer>

    <!-- jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
    <!-- custom scripts -->
    <script src="js/script.js"></script>

</body>
</html>